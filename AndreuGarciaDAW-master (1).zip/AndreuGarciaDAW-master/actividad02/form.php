<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>actividad02</title>
    <style media="screen" type="text/css">
    div{
      width: 157px;;
      height: 150px;
      padding: 5px;
      margin: 5px;
      background-color: rgb(0,0,0);
      display:inline-block;
    }
    </style>
  </head>
  <body>
    <form action="fichero.php" method="post">
      <p>Red: <input type="text" name="red" /></p>
      <p>Green: <input type="text" name="green" /></p>
      <p>Blue: <input type="text" name="blue" /></p>
      <p><input type="submit" /></p>
    </form>
  </body>
</html>
