<form class="formulario" action="recibirDatos.php" method="post">
  <h3>Actividad03</h3>
  Nombre: <br>
  <input type="text" name="nombre" value="">
  <br>
  Texto: <br>
  <input type="text" name="texto" value="">
  <br>
  Palabras a destacar: <br>
  <input type="text" name="palabras" value="">
  <br>
  <br>
  <input type="submit" name="" value="Enviar">
</form>
